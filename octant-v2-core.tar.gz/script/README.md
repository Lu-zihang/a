# Scripts used by Octant v2

This directory contains scripts used by Octant v2.

Script directories:

- `demo` - TBD
- `deploy` - scripts used by deployments
- `deployment` - scripts used to deploy on CD envs
- `helpers` - TBD
- `prod` - TBD
- `trader` - TBD
